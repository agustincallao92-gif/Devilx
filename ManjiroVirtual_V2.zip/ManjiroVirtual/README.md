# MANJIRO VIRTUAL [V2]
### Android App Virtualizer — 32-bit APK Cloner

---

## ✅ SETUP IN 5 STEPS

### Step 1 — Download Android Studio
https://developer.android.com/studio
(Free. Install it, open it, let it finish downloading SDK tools)

---

### Step 2 — Open this project
- In Android Studio: File → Open → select this ManjiroVirtual folder

---

### Step 3 — Add the Orbitron font
1. Go to: https://fonts.google.com/specimen/Orbitron
2. Download → extract → find `Orbitron-Bold.ttf`
3. Copy it to: `app/src/main/res/font/orbitron_bold.ttf`
4. Delete the file `app/src/main/res/font/orbitron_bold.xml`

---

### Step 4 — Add the VirtualApp engine (FOR REAL CLONING)
This is what makes apps actually run inside the virtual space.

```bash
# In your terminal, inside the ManjiroVirtual folder:
git clone https://github.com/asLody/VirtualApp VirtualApp
```

Then open `settings.gradle` and add:
```groovy
include ':VirtualApp'
```

Then open `app/build.gradle` and uncomment:
```groovy
implementation project(':VirtualApp')
```

Then in `VirtualEngine.java`, uncomment the VirtualCore lines.
Then in `ManjiroApp.java`, uncomment the startup line.

---

### Step 5 — Build & Run
- Plug in your Android phone (USB debugging ON)
- Click the green ▶ Run button in Android Studio
- Done!

---

## 📱 WHAT THE APP DOES

| Feature | Works |
|---|---|
| Shows all apps installed on your phone | ✅ |
| Browse APK from storage | ✅ |
| Clone progress UI with steps | ✅ |
| Cloned apps list | ✅ |
| Launch cloned app | ✅ (needs VirtualApp for true isolation) |
| Search installed apps | ✅ |
| Remove clones | ✅ |
| @DevXyto Telegram link | ✅ |
| 32-bit APK sandbox (real virtual) | ✅ after Step 4 |

---

## 📞 DEVELOPER
Telegram: http://t.me/DevXyto

---

## ⚠️ NOTE
VirtualApp (the engine) is open-source (LGPL). Read their license before publishing.
