package com.manjiro.virtual.ui;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.manjiro.virtual.R;
import com.manjiro.virtual.adapter.AppListAdapter;
import com.manjiro.virtual.adapter.ClonedAppAdapter;
import com.manjiro.virtual.engine.VirtualEngine;
import com.manjiro.virtual.model.InstalledApp;
import com.manjiro.virtual.util.CloneManager;
import java.util.ArrayList;
import java.util.List;
import android.app.AlertDialog;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity
        implements AppListAdapter.OnAppActionListener {

    private RecyclerView rvApps, rvCloned;
    private AppListAdapter appAdapter;
    private ClonedAppAdapter clonedAdapter;
    private List<InstalledApp> allApps = new ArrayList<>();
    private List<InstalledApp> clonedApps = new ArrayList<>();
    private VirtualEngine engine;
    private CloneManager cloneManager;
    private LinearLayout panelApps, panelCloned, panelAbout, panelSettings;

    // APK file picker
    private final ActivityResultLauncher<String[]> apkPicker =
        registerForActivityResult(new ActivityResultContracts.OpenDocument(), uri -> {
            if (uri != null) handleApkUri(uri);
        });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        engine = VirtualEngine.get(this);
        cloneManager = new CloneManager(this);

        setupViews();
        setupTabs();
        setupFab();
        requestPermissionsIfNeeded();
        loadInstalledApps();
    }

    private void setupViews() {
        panelApps     = findViewById(R.id.panel_apps);
        panelCloned   = findViewById(R.id.panel_cloned);
        panelAbout    = findViewById(R.id.panel_about);
        panelSettings = findViewById(R.id.panel_settings);

        rvApps = findViewById(R.id.rv_apps);
        rvCloned = findViewById(R.id.rv_cloned);

        appAdapter = new AppListAdapter(allApps, this);
        rvApps.setLayoutManager(new LinearLayoutManager(this));
        rvApps.setAdapter(appAdapter);
        rvApps.setHasFixedSize(false);

        clonedAdapter = new ClonedAppAdapter(clonedApps, this::onLaunchApp, this::onRemoveClone);
        rvCloned.setLayoutManager(new LinearLayoutManager(this));
        rvCloned.setAdapter(clonedAdapter);

        // Search button → SearchActivity
        View searchBtn = findViewById(R.id.btn_search);
        if (searchBtn != null) {
            searchBtn.setOnClickListener(v ->
                startActivity(new Intent(this, SearchActivity.class)));
        }

        // Developer Telegram link
        View devCard = findViewById(R.id.dev_card);
        if (devCard != null) {
            devCard.setOnClickListener(v -> {
                Intent i = new Intent(Intent.ACTION_VIEW, Uri.parse("https://t.me/DevXyto"));
                startActivity(i);
            });
        }
    }

    private void setupTabs() {
        TabLayout tabs = findViewById(R.id.tabs);
        tabs.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override public void onTabSelected(TabLayout.Tab tab) { switchPanel(tab.getPosition()); }
            @Override public void onTabUnselected(TabLayout.Tab tab) {}
            @Override public void onTabReselected(TabLayout.Tab tab) {}
        });
        switchPanel(0);
    }

    private void switchPanel(int pos) {
        panelApps.setVisibility(pos == 0 ? View.VISIBLE : View.GONE);
        panelCloned.setVisibility(pos == 1 ? View.VISIBLE : View.GONE);
        panelAbout.setVisibility(pos == 2 ? View.VISIBLE : View.GONE);
        panelSettings.setVisibility(pos == 3 ? View.VISIBLE : View.GONE);
    }

    private void setupFab() {
        FloatingActionButton fab = findViewById(R.id.fab);
        fab.setOnClickListener(v -> showAddDialog());
    }

    // ── Load all installed apps from device ───────────────────────────────
    private void loadInstalledApps() {
        new Thread(() -> {
            List<InstalledApp> apps = engine.getInstalledApps();
            // Mark already-cloned apps
            List<String> clonedPkgs = cloneManager.getClonedPackages();
            for (InstalledApp a : apps) {
                if (clonedPkgs.contains(a.getPackageName())) {
                    a.setCloned(true);
                    clonedApps.add(a);
                }
            }
            allApps.addAll(apps);
            runOnUiThread(() -> {
                appAdapter.notifyDataSetChanged();
                clonedAdapter.notifyDataSetChanged();
            });
        }).start();
    }

    // ── Clone button tapped ───────────────────────────────────────────────
    @Override
    public void onCloneApp(InstalledApp app) {
        CloneProgressDialog dialog = new CloneProgressDialog(this, app, engine, cloneManager,
            clonedApp -> {
                if (!clonedApps.contains(clonedApp)) {
                    clonedApps.add(clonedApp);
                    clonedAdapter.notifyItemInserted(clonedApps.size() - 1);
                }
                appAdapter.notifyDataSetChanged();
            });
        dialog.show();
    }

    // ── Launch cloned app ─────────────────────────────────────────────────
    private void onLaunchApp(InstalledApp app) {
        engine.launchApp(this, app);
    }

    // ── Remove clone ──────────────────────────────────────────────────────
    private void onRemoveClone(InstalledApp app) {
        new AlertDialog.Builder(this)
            .setTitle("Remove Clone")
            .setMessage("Remove the cloned instance of " + app.getAppName() + "?")
            .setPositiveButton("Remove", (d, w) -> {
                engine.uninstallApp(app);
                cloneManager.removeClone(app.getPackageName());
                int idx = clonedApps.indexOf(app);
                clonedApps.remove(app);
                if (idx >= 0) clonedAdapter.notifyItemRemoved(idx);
                appAdapter.notifyDataSetChanged();
                toast("Clone removed.");
            })
            .setNegativeButton("Cancel", null)
            .show();
    }

    // ── Add from phone storage ────────────────────────────────────────────
    private void showAddDialog() {
        String[] options = {"Browse APK from storage", "Pick from installed apps"};
        new AlertDialog.Builder(this)
            .setTitle("Add App")
            .setItems(options, (d, which) -> {
                if (which == 0) apkPicker.launch(new String[]{"application/vnd.android.package-archive"});
                else scrollToApps();
            }).show();
    }

    private void scrollToApps() {
        TabLayout tabs = findViewById(R.id.tabs);
        if (tabs != null && tabs.getTabAt(0) != null)
            tabs.getTabAt(0).select();
        toast("Tap + next to any app to clone it");
    }

    private void handleApkUri(Uri uri) {
        // Get real path or handle content URI
        try {
            String path = uri.getPath();
            String name = uri.getLastPathSegment();
            if (name != null) name = name.replace(".apk","");
            // Create a virtual app entry from this APK
            InstalledApp customApp = new InstalledApp(
                name != null ? name : "Custom App",
                "com.custom." + (name != null ? name.toLowerCase().replaceAll("\\s","") : "app"),
                path != null ? path : uri.toString(),
                "? MB",
                ContextCompat.getDrawable(this, R.drawable.ic_default_app)
            );
            allApps.add(0, customApp);
            appAdapter.notifyItemInserted(0);
            rvApps.scrollToPosition(0);
            toast(customApp.getAppName() + " added. Tap + to clone.");
        } catch (Exception e) {
            toast("Could not read APK: " + e.getMessage());
        }
    }

    // ── Permissions ───────────────────────────────────────────────────────
    private void requestPermissionsIfNeeded() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            // Android 13+: query packages is declared in manifest
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 1001);
            }
        }
    }

    private void toast(String msg) {
        Toast.makeText(this, msg, Toast.LENGTH_SHORT).show();
    }
}
