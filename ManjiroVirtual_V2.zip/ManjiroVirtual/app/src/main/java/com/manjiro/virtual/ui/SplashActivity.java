package com.manjiro.virtual.ui;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.view.animation.AlphaAnimation;
import android.view.animation.Animation;
import android.view.animation.ScaleAnimation;
import android.view.animation.AnimationSet;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.ProgressBar;
import androidx.appcompat.app.AppCompatActivity;
import com.manjiro.virtual.R;

public class SplashActivity extends AppCompatActivity {

    private static final int SPLASH_DURATION = 2800;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash);

        ImageView logo = findViewById(R.id.splash_logo);
        TextView brand = findViewById(R.id.splash_brand);
        TextView tagline = findViewById(R.id.splash_tagline);
        ProgressBar loadBar = findViewById(R.id.splash_loadbar);

        // Logo zoom-in + fade
        AnimationSet logoAnim = new AnimationSet(true);
        ScaleAnimation scale = new ScaleAnimation(
            0.3f, 1f, 0.3f, 1f,
            Animation.RELATIVE_TO_SELF, 0.5f,
            Animation.RELATIVE_TO_SELF, 0.5f);
        AlphaAnimation fade = new AlphaAnimation(0f, 1f);
        scale.setDuration(900);
        fade.setDuration(900);
        logoAnim.addAnimation(scale);
        logoAnim.addAnimation(fade);
        logoAnim.setInterpolator(new AccelerateDecelerateInterpolator());
        logo.startAnimation(logoAnim);

        // Brand text fade in delayed
        AlphaAnimation brandFade = new AlphaAnimation(0f, 1f);
        brandFade.setDuration(700);
        brandFade.setStartOffset(600);
        brandFade.setFillAfter(true);
        brand.startAnimation(brandFade);

        // Tagline fade
        AlphaAnimation tagFade = new AlphaAnimation(0f, 1f);
        tagFade.setDuration(600);
        tagFade.setStartOffset(900);
        tagFade.setFillAfter(true);
        tagline.startAnimation(tagFade);

        // Go to main after splash
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out);
            finish();
        }, SPLASH_DURATION);
    }
}
