package com.manjiro.virtual.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.manjiro.virtual.R;
import com.manjiro.virtual.model.InstalledApp;
import java.util.List;

public class ClonedAppAdapter extends RecyclerView.Adapter<ClonedAppAdapter.VH> {

    public interface OnAction { void run(InstalledApp app); }

    private final List<InstalledApp> apps;
    private final OnAction onLaunch, onRemove;

    public ClonedAppAdapter(List<InstalledApp> apps, OnAction onLaunch, OnAction onRemove) {
        this.apps = apps;
        this.onLaunch = onLaunch;
        this.onRemove = onRemove;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_cloned_app, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        InstalledApp app = apps.get(pos);
        if (app.getIcon() != null) h.icon.setImageDrawable(app.getIcon());
        h.name.setText(app.getAppName() + " [CLONE]");
        h.pkg.setText(app.getPackageName() + " · " + app.getApkSize());
        h.itemView.setOnClickListener(v -> onLaunch.run(app));
        h.removeBtn.setOnClickListener(v -> onRemove.run(app));
    }

    @Override public int getItemCount() { return apps.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView icon, removeBtn;
        TextView name, pkg;
        VH(View v) {
            super(v);
            icon      = v.findViewById(R.id.cloned_icon);
            name      = v.findViewById(R.id.cloned_name);
            pkg       = v.findViewById(R.id.cloned_pkg);
            removeBtn = v.findViewById(R.id.cloned_remove);
        }
    }
}
