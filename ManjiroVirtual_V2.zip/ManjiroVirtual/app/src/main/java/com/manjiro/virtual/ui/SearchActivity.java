package com.manjiro.virtual.ui;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.manjiro.virtual.R;
import com.manjiro.virtual.adapter.AppListAdapter;
import com.manjiro.virtual.engine.VirtualEngine;
import com.manjiro.virtual.model.InstalledApp;
import com.manjiro.virtual.util.CloneManager;
import java.util.ArrayList;
import java.util.List;

public class SearchActivity extends AppCompatActivity
        implements AppListAdapter.OnAppActionListener {

    private List<InstalledApp> allApps = new ArrayList<>();
    private List<InstalledApp> filtered = new ArrayList<>();
    private AppListAdapter adapter;
    private VirtualEngine engine;
    private CloneManager cloneManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        engine = VirtualEngine.get(this);
        cloneManager = new CloneManager(this);

        RecyclerView rv = findViewById(R.id.search_rv);
        adapter = new AppListAdapter(filtered, this);
        rv.setLayoutManager(new LinearLayoutManager(this));
        rv.setAdapter(adapter);

        EditText searchInput = findViewById(R.id.search_input);
        ImageView closeBtn   = findViewById(R.id.search_close);

        closeBtn.setOnClickListener(v -> finish());

        searchInput.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) { filter(s.toString()); }
            @Override public void afterTextChanged(Editable s) {}
        });

        // Load apps in background
        new Thread(() -> {
            allApps = engine.getInstalledApps();
            runOnUiThread(() -> filter(""));
        }).start();
    }

    private void filter(String q) {
        filtered.clear();
        String lower = q.toLowerCase().trim();
        for (InstalledApp a : allApps) {
            if (lower.isEmpty()
                    || a.getAppName().toLowerCase().contains(lower)
                    || a.getPackageName().toLowerCase().contains(lower)) {
                filtered.add(a);
            }
        }
        adapter.notifyDataSetChanged();
    }

    @Override
    public void onCloneApp(InstalledApp app) {
        CloneProgressDialog dialog = new CloneProgressDialog(this, app, engine, cloneManager,
            cloned -> {
                adapter.notifyDataSetChanged();
                setResult(RESULT_OK);
            });
        dialog.show();
    }
}
