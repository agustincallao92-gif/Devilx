package com.manjiro.virtual.engine;

import android.content.Context;
import android.content.Intent;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.util.Log;
import com.manjiro.virtual.model.InstalledApp;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * VirtualEngine — wraps VirtualApp (or any virtual framework).
 *
 * HOW TO ACTIVATE THE REAL ENGINE:
 * 1. git clone https://github.com/asLody/VirtualApp  (into project root)
 * 2. Add  implementation project(':VirtualApp')  in app/build.gradle
 * 3. Uncomment the VirtualCore lines below
 * 4. Rebuild — real cloning and launching will work.
 */
public class VirtualEngine {

    private static final String TAG = "VirtualEngine";
    private static VirtualEngine instance;
    private final Context context;
    private boolean engineReady = false;

    private VirtualEngine(Context ctx) {
        this.context = ctx.getApplicationContext();
    }

    public static VirtualEngine get(Context ctx) {
        if (instance == null) instance = new VirtualEngine(ctx);
        return instance;
    }

    // ── Engine startup ────────────────────────────────────────────────────
    public void startup() {
        // Uncomment after adding VirtualApp:
        // VirtualCore.get().startup(context, new AppCallback() { ... });
        engineReady = true;
        Log.i(TAG, "Engine startup OK");
    }

    // ── Install (clone) an APK into the virtual space ─────────────────────
    public interface InstallCallback {
        void onProgress(int percent, String message);
        void onSuccess(InstalledApp app);
        void onError(String error);
    }

    public void installApp(final InstalledApp app, final InstallCallback cb) {
        new Thread(() -> {
            try {
                cb.onProgress(10, "Verifying 32-bit architecture...");
                Thread.sleep(400);

                // Real implementation:
                // int result = VirtualCore.get().installPackage(app.getApkPath(), 0);
                // if (result != InstallResult.SUCCESS) { cb.onError("Install failed"); return; }

                cb.onProgress(30, "Allocating virtual space...");
                Thread.sleep(500);

                cb.onProgress(55, "Copying APK data...");
                Thread.sleep(600);

                cb.onProgress(75, "Applying virtual patches...");
                Thread.sleep(500);

                cb.onProgress(90, "Configuring sandbox...");
                Thread.sleep(400);

                app.setCloned(true);
                cb.onProgress(100, "Clone ready!");
                cb.onSuccess(app);

            } catch (Exception e) {
                cb.onError(e.getMessage());
            }
        }).start();
    }

    // ── Launch a cloned app ───────────────────────────────────────────────
    public void launchApp(Context ctx, InstalledApp app) {
        if (!app.isCloned()) {
            Log.w(TAG, "App not cloned yet: " + app.getPackageName());
            return;
        }
        // Real implementation:
        // VirtualCore.get().launchApp(app.getPackageName(), 0);

        // Stub: try launching the real app for now
        try {
            PackageManager pm = ctx.getPackageManager();
            Intent launch = pm.getLaunchIntentForPackage(app.getPackageName());
            if (launch != null) {
                launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(launch);
            }
        } catch (Exception e) {
            Log.e(TAG, "Launch failed: " + e.getMessage());
        }
    }

    // ── Get all installed apps on the real device ─────────────────────────
    public List<InstalledApp> getInstalledApps() {
        List<InstalledApp> result = new ArrayList<>();
        PackageManager pm = context.getPackageManager();
        List<PackageInfo> packages = pm.getInstalledPackages(0);

        for (PackageInfo pkg : packages) {
            try {
                // Skip system apps
                if ((pkg.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0) continue;

                String name = pm.getApplicationLabel(pkg.applicationInfo).toString();
                String pkgName = pkg.packageName;
                String apkPath = pkg.applicationInfo.sourceDir;
                File apkFile = new File(apkPath);
                String size = formatSize(apkFile.length());
                android.graphics.drawable.Drawable icon = pm.getApplicationIcon(pkg.applicationInfo);

                result.add(new InstalledApp(name, pkgName, apkPath, size, icon));
            } catch (Exception e) {
                // skip apps we can't read
            }
        }

        // Sort alphabetically
        result.sort((a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));
        return result;
    }

    // ── Uninstall from virtual space ──────────────────────────────────────
    public void uninstallApp(InstalledApp app) {
        // VirtualCore.get().uninstallPackage(app.getPackageName(), 0);
        app.setCloned(false);
        Log.i(TAG, "Uninstalled virtual: " + app.getPackageName());
    }

    private String formatSize(long bytes) {
        if (bytes < 1024 * 1024) return (bytes / 1024) + " KB";
        if (bytes < 1024L * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB", bytes / (1024.0 * 1024 * 1024));
    }

    public boolean isEngineReady() { return engineReady; }
}
