package com.manjiro.virtual.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.manjiro.virtual.R;
import com.manjiro.virtual.model.InstalledApp;
import java.util.List;

public class AppListAdapter extends RecyclerView.Adapter<AppListAdapter.VH> {

    public interface OnAppActionListener {
        void onCloneApp(InstalledApp app);
    }

    private final List<InstalledApp> apps;
    private final OnAppActionListener listener;

    public AppListAdapter(List<InstalledApp> apps, OnAppActionListener listener) {
        this.apps = apps;
        this.listener = listener;
    }

    @NonNull @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_app, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int pos) {
        InstalledApp app = apps.get(pos);

        if (app.getIcon() != null) h.icon.setImageDrawable(app.getIcon());
        h.name.setText(app.getAppName());
        h.pkg.setText(app.getPackageName() + " · " + app.getApkSize());
        h.badge32.setText("32-BIT");

        if (app.isCloned()) {
            h.clonedBadge.setVisibility(View.VISIBLE);
            h.cloneBtn.setText("✓");
            h.cloneBtn.setAlpha(0.5f);
        } else {
            h.clonedBadge.setVisibility(View.GONE);
            h.cloneBtn.setText("+");
            h.cloneBtn.setAlpha(1f);
        }

        h.cloneBtn.setOnClickListener(v -> {
            if (!app.isCloned()) listener.onCloneApp(app);
        });
    }

    @Override public int getItemCount() { return apps.size(); }

    static class VH extends RecyclerView.ViewHolder {
        ImageView icon;
        TextView name, pkg, badge32, clonedBadge;
        Button cloneBtn;
        VH(View v) {
            super(v);
            icon        = v.findViewById(R.id.app_icon);
            name        = v.findViewById(R.id.app_name);
            pkg         = v.findViewById(R.id.app_pkg);
            badge32     = v.findViewById(R.id.badge_32);
            clonedBadge = v.findViewById(R.id.badge_cloned);
            cloneBtn    = v.findViewById(R.id.btn_clone);
        }
    }
}
