package com.manjiro.virtual.ui;

import android.app.Dialog;
import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Handler;
import android.os.Looper;
import android.view.Window;
import android.widget.*;
import com.manjiro.virtual.R;
import com.manjiro.virtual.engine.VirtualEngine;
import com.manjiro.virtual.model.InstalledApp;
import com.manjiro.virtual.util.CloneManager;

public class CloneProgressDialog extends Dialog {

    public interface OnCloneComplete {
        void onComplete(InstalledApp app);
    }

    private final InstalledApp app;
    private final VirtualEngine engine;
    private final CloneManager cloneManager;
    private final OnCloneComplete callback;

    public CloneProgressDialog(Context ctx, InstalledApp app,
                               VirtualEngine engine, CloneManager cloneManager,
                               OnCloneComplete callback) {
        super(ctx);
        this.app = app;
        this.engine = engine;
        this.cloneManager = cloneManager;
        this.callback = callback;
    }

    @Override
    public void show() {
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        setContentView(R.layout.dialog_clone_progress);
        if (getWindow() != null) {
            getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        setCancelable(false);

        ImageView appIcon   = findViewById(R.id.clone_app_icon);
        TextView appName    = findViewById(R.id.clone_app_name);
        TextView statusText = findViewById(R.id.clone_status);
        ProgressBar progress= findViewById(R.id.clone_progress);
        TextView pctText    = findViewById(R.id.clone_percent);
        TextView s1 = findViewById(R.id.step1);
        TextView s2 = findViewById(R.id.step2);
        TextView s3 = findViewById(R.id.step3);
        TextView s4 = findViewById(R.id.step4);
        TextView s5 = findViewById(R.id.step5);
        Button closeBtn = findViewById(R.id.clone_close_btn);

        if (app.getIcon() != null) appIcon.setImageDrawable(app.getIcon());
        appName.setText("CLONING " + app.getAppName().toUpperCase());
        closeBtn.setVisibility(android.view.View.GONE);

        super.show();

        engine.installApp(app, new VirtualEngine.InstallCallback() {
            final Handler h = new Handler(Looper.getMainLooper());

            @Override public void onProgress(int pct, String message) {
                h.post(() -> {
                    progress.setProgress(pct);
                    pctText.setText(pct + "%");
                    statusText.setText(message);
                    // Light up steps
                    if (pct >= 10)  markDone(s1);
                    if (pct >= 30)  markDone(s2);
                    if (pct >= 55)  markDone(s3);
                    if (pct >= 75)  markDone(s4);
                    if (pct >= 100) markDone(s5);
                });
            }

            @Override public void onSuccess(InstalledApp result) {
                cloneManager.saveClone(result.getPackageName());
                h.post(() -> {
                    closeBtn.setVisibility(android.view.View.VISIBLE);
                    closeBtn.setOnClickListener(v -> {
                        dismiss();
                        callback.onComplete(result);
                    });
                });
            }

            @Override public void onError(String error) {
                h.post(() -> {
                    statusText.setText("Error: " + error);
                    closeBtn.setText("CLOSE");
                    closeBtn.setVisibility(android.view.View.VISIBLE);
                    closeBtn.setOnClickListener(v -> dismiss());
                });
            }
        });
    }

    private void markDone(TextView tv) {
        if (tv != null) tv.setCompoundDrawablesWithIntrinsicBounds(R.drawable.ic_check_neon, 0, 0, 0);
    }
}
