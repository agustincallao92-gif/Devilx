package com.manjiro.virtual.model;

import android.graphics.drawable.Drawable;

public class InstalledApp {
    private String appName;
    private String packageName;
    private String apkPath;
    private String apkSize;
    private Drawable icon;
    private boolean isCloned;
    private boolean isRunning;
    private int userId; // virtual user ID (0 = original, 1+ = clones)

    public InstalledApp(String appName, String packageName, String apkPath,
                        String apkSize, Drawable icon) {
        this.appName = appName;
        this.packageName = packageName;
        this.apkPath = apkPath;
        this.apkSize = apkSize;
        this.icon = icon;
        this.isCloned = false;
        this.isRunning = false;
        this.userId = 0;
    }

    // Getters
    public String getAppName()     { return appName; }
    public String getPackageName() { return packageName; }
    public String getApkPath()     { return apkPath; }
    public String getApkSize()     { return apkSize; }
    public Drawable getIcon()      { return icon; }
    public boolean isCloned()      { return isCloned; }
    public boolean isRunning()     { return isRunning; }
    public int getUserId()         { return userId; }

    // Setters
    public void setCloned(boolean cloned)   { isCloned = cloned; }
    public void setRunning(boolean running) { isRunning = running; }
    public void setUserId(int id)           { userId = id; }
}
