package com.manjiro.virtual.engine;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;

public class VirtualEngineService extends Service {
    private static final String TAG = "VirtualEngineService";

    @Override
    public void onCreate() {
        super.onCreate();
        Log.i(TAG, "Virtual engine service started");
        VirtualEngine.get(this).startup();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }
}
