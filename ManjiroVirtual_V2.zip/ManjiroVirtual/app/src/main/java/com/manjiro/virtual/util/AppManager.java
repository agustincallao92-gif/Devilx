package com.manjiro.virtual.util;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import com.manjiro.virtual.model.InstalledApp;
import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class AppManager {

    /**
     * Returns all user-installed apps, sorted A-Z.
     * Filters out system apps automatically.
     */
    public static List<InstalledApp> getUserApps(Context ctx) {
        List<InstalledApp> result = new ArrayList<>();
        PackageManager pm = ctx.getPackageManager();

        List<PackageInfo> packages = pm.getInstalledPackages(0);
        for (PackageInfo pkg : packages) {
            try {
                // Skip system apps
                boolean isSystem = (pkg.applicationInfo.flags & ApplicationInfo.FLAG_SYSTEM) != 0;
                if (isSystem) continue;

                String name    = pm.getApplicationLabel(pkg.applicationInfo).toString();
                String pkgName = pkg.packageName;
                String apkPath = pkg.applicationInfo.sourceDir;
                String size    = formatSize(new File(apkPath).length());
                android.graphics.drawable.Drawable icon =
                        pm.getApplicationIcon(pkg.applicationInfo);

                result.add(new InstalledApp(name, pkgName, apkPath, size, icon));
            } catch (Exception ignored) {}
        }

        result.sort((a, b) -> a.getAppName().compareToIgnoreCase(b.getAppName()));
        return result;
    }

    public static String formatSize(long bytes) {
        if (bytes <= 0)                   return "? MB";
        if (bytes < 1024 * 1024)         return (bytes / 1024) + " KB";
        if (bytes < 1024L * 1024 * 1024) return String.format("%.1f MB", bytes / (1024.0 * 1024));
        return String.format("%.2f GB",   bytes / (1024.0 * 1024 * 1024));
    }
}
