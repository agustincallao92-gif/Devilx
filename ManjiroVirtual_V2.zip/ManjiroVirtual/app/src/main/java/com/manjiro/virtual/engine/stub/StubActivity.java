package com.manjiro.virtual.engine.stub;

import android.app.Activity;

/**
 * Stub activities used by the virtual engine to host cloned app activities.
 * VirtualApp hooks into these at runtime and replaces them with the real app UI.
 */
public class StubActivity extends Activity {

    public static class C0 extends StubActivity {}
    public static class C1 extends StubActivity {}
    public static class C2 extends StubActivity {}
}
