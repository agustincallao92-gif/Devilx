package com.manjiro.virtual.util;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class CloneManager {
    private static final String PREFS = "manjiro_clones";
    private static final String KEY   = "cloned_packages";
    private final SharedPreferences prefs;

    public CloneManager(Context ctx) {
        prefs = ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
    }

    public void saveClone(String packageName) {
        Set<String> set = new HashSet<>(prefs.getStringSet(KEY, new HashSet<>()));
        set.add(packageName);
        prefs.edit().putStringSet(KEY, set).apply();
    }

    public void removeClone(String packageName) {
        Set<String> set = new HashSet<>(prefs.getStringSet(KEY, new HashSet<>()));
        set.remove(packageName);
        prefs.edit().putStringSet(KEY, set).apply();
    }

    public List<String> getClonedPackages() {
        return new ArrayList<>(prefs.getStringSet(KEY, new HashSet<>()));
    }

    public boolean isCloned(String packageName) {
        return prefs.getStringSet(KEY, new HashSet<>()).contains(packageName);
    }
}
