package com.manjiro.virtual;

import android.app.Application;
import android.util.Log;
import androidx.multidex.MultiDex;
import android.content.Context;

public class ManjiroApp extends Application {

    private static final String TAG = "ManjiroVirtual";
    private static ManjiroApp instance;

    @Override
    protected void attachBaseContext(Context base) {
        super.attachBaseContext(base);
        MultiDex.install(this);
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        Log.i(TAG, "Manjiro Virtual V2 starting...");
        initVirtualEngine();
    }

    private void initVirtualEngine() {
        // ── VirtualApp Engine Init ─────────────────────────────────────────
        // After adding VirtualApp dependency, replace this block with:
        //
        //   VirtualCore.get().startup(this, new AppCallback());
        //
        // ──────────────────────────────────────────────────────────────────
        Log.i(TAG, "Virtual engine ready (stub mode - add VirtualApp to activate)");
    }

    public static ManjiroApp getInstance() {
        return instance;
    }
}
