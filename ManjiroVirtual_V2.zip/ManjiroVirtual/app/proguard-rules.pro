# Manjiro Virtual ProGuard Rules

# Keep VirtualApp classes when added
-keep class com.lody.virtual.** { *; }
-keep class mirror.** { *; }

# Keep our engine and model classes
-keep class com.manjiro.virtual.engine.** { *; }
-keep class com.manjiro.virtual.model.** { *; }

# Keep Glide
-keep public class * implements com.bumptech.glide.module.GlideModule
-keep class * extends com.bumptech.glide.module.AppGlideModule { *; }
-keep public enum com.bumptech.glide.load.ImageHeaderParser$** { *; }

# General Android
-keepattributes *Annotation*
-keepattributes SourceFile,LineNumberTable
